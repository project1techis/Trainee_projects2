from django.apps import AppConfig


class ItemsConfig(AppConfig):
    name = 'apps.items'
