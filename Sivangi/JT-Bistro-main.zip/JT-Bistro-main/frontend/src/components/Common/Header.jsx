import React from "react";
import MainImage from"../../assets/img/background-image.png"
import ImgLogo from "../../assets/img/Screenshot.png";

const Header = () => {
  return (
    <header>
      
      <img src={ImgLogo} alt="" />
    </header>
  );
};

export default Header;
