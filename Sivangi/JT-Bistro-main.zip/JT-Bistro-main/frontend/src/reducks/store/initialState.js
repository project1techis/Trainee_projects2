const initialState = { 
    posts: {
        list: []
    },
    items: {
        list: []
    },
    carts: {
        list: [],
        subtotal: 0
    }
};

export default initialState