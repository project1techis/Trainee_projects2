////////////////////////////
//////Javascript post page
///////////////////////////

// alert('here!')

$(function(){
    $('.js-menu-icon').click(function() {
        // alert('clicked!!!');
        $(this).next().toggle();
    })
})

 