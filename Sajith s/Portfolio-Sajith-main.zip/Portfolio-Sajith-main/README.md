# Portfolio
This portfolio is a small project using the HTML/CSS and Bootstrap. I will be using the this to showcase my projects and skills [LIVE REPLIT DEPLOYMENT](https://portfolio-sajith.sajith-1.repl.co/)

# Screenshot:
![Screenshot 2022-09-23 at 1 40 22 PM](https://user-images.githubusercontent.com/112057794/191918006-9fdf0688-09be-4e16-bef5-340de4c96013.png)

# Technologies Used:
* HTML 
* CSS

# Installation
 No need to install any software, just open up index.html
 
# How to use?
Use this template to build your own portfolio
