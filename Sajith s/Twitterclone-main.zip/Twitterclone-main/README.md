# Twitterclone.
This is a demo website for Twitter. Users can post, tweet, like just like doing in actual twitter.

Screenshot ![Screenshot 2022-10-21 at 12 07 43 PM](https://user-images.githubusercontent.com/112057794/197129312-8f2a551d-00cb-4071-967a-8e400c75154e.png)






Technologies used
* HTML
* CSS
* BootStrap
* JavaScript / JQuery
* Django
* Cloudinary

User Story
* User can tweet
* User can edit
* User can delete tweet
* User can like
