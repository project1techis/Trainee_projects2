# PORTFOLIO
This Portfolio is a small project using HTML / CSS and Bootstrap. I will be using this to show my projects!

## Screenshot:
 <img width="1380" alt="Screenshot 2022-07-08 at 4 10 25 PM" src="https://user-images.githubusercontent.com/108518744/177977247-d59d7be1-a0a4-4748-9341-472da0973d7c.png">

## Technologies Used
* HTML
* CSS
## Installation
No need to install any software, just open up index.html
## How to use ?
Use this template to build your own portfolio
