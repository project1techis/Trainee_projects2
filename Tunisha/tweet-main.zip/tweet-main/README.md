
# Twitter-Clone
A sample web page of twitter
Twitter Clone
Let's make simple Twitter. Users can post tweets and see everyone's them.
To make the project simple, we do not have a sign/login function.
So there are not user accounts and follow function. You can challenge after you finish the course.
Check out [LIVE DEMO here!!](https://tweet.tunishapradhan.repl.co/)

# Screenshot
<img width="760" alt="Screenshot 2022-09-23 at 3 50 51 PM" src="https://user-images.githubusercontent.com/108518744/191940828-8bd3aaee-89ec-4c5a-9993-338add7a82e7.png">



# Tech used
* Html
* Css
* Bootstrap
* Javascript / JQuery
* Django
* Cloudinary (To host uploaded images on CDN)

# User Story
* Users can post tweets.
* Users can edit tweets.
* Users can delete tweets.
* Users can send a like to a tweet.

