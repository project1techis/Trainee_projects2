// Java Script for tweets page //


$(function() {
    $('.js-menu-icon').click(function() {
        $(this).next().toggle();
    })
})