
# Twitter-Clone
A sample web page of twitter
Twitter Clone
Let's make simple Twitter. Users can post tweets and see everyone's them.
To make the project simple, we do not have a sign/login function.
So there are not user accounts and follow function. You can challenge after you finish the course.
Check out [LIVE DEMO here!!](https://twitterclone.thejasb1.repl.co/)

# Screenshot



<img width="1391" alt="Twitter-clone" src="https://user-images.githubusercontent.com/100840312/160105197-e22ba7e2-2994-4766-bac0-a0f79a4370a7.png">




# Tech used
* Html
* Css
* Bootstrap
* Javascript / JQuery
* Django
* Cloudinary (To host uploaded images on CDN)

# User Story
* Users can post tweets.
* Users can edit tweets.
* Users can delete tweets.
* Users can send a like to a tweet.

