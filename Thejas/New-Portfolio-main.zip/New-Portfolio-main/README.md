# PORTFOLIO

This Portfolio is a small project using HTML / CSS and Bootstrap. I will be using this to showmy projects!

[Live Heroku Deployment](https://new-portfolio.thejasb1.repl.co/)

## Screenshot:
 ![Screenshot 2022-09-22 at 3 24 14 PM](https://user-images.githubusercontent.com/100840312/191717076-c64c3974-31d7-442f-abc6-925442beec30.png)



## Technologies Used

* HTML
* CSS

## Installation 

No need to install any software, just open up index.html

## How to use ?

Use this template to build your own portfolio 
