# PORTFOLIO
This Portfolio is a small project using HTML / CSS and Bootstrap. I will be using this to show my projects!
[Live Replit deployment]()


## Technologies Used
* HTML
* CSS

## Installation
No need to install any software, just open up index.html

## How to use ?
Use this template to build your own portfolio

## Screenshot: