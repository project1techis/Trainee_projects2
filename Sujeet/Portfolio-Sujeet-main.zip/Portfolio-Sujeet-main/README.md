# Portfolio
This Portfolio is a small project using HTML / CSS and Bootstrap. I will be using this to show my projects!
[Live Heroku Deployment](https://portfolio-sujeet.herokuapp.com/#Projects)
## Screenshot:
 <img width="848" alt="Screenshot 2022-07-22 at 1 28 50 PM" src="https://user-images.githubusercontent.com/107241919/180392443-a5861d05-74db-4e5b-ad1d-19fcd911676e.png">

## Technologies Used
* HTML
* CSS
## Installation
No need to install any software, just open up index.html
## How to use ?
