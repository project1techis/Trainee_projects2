const initialState = { 
    places: {
        list: []
    },
    categories: {
        list: [],
      },
      favourites: {
        list: [],
      },
    
    
};


export default initialState